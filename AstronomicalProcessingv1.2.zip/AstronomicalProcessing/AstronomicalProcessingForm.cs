﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// C Sharp 1 Assessment 2
// James Boyd, Team Elljam, Sprint Number One
// Date: 14/09/2021
// Version 1.2 (All functions implemented, error trapping included, useful user feedback messages)
// Astronomical Processing
//
// Explanation: A program for a local observatory that stores the number of neutrino
// interactions per hour as integer values in an array of size 24. This forms-based 
// GUI application displays the data in a list box and uses text boxes and buttons for processing.
//
// Functionality: User can add/remove/edit data using a textbox for input. Data can be
// sorted or searched. An option to randomly generate data with a button press is included


namespace AstronomicalProcessing
{
    public partial class AstronomicalProcessingForm : Form
    {
        public AstronomicalProcessingForm()
        {
            InitializeComponent();
        }
        // •	The array is of type integer.
        // •	The array has 24 elements to reflect the number of hours per day.
        static int max = 24;
        int[] astroArray = new int[max];
        int nextEmpty = 0;
        Random rnd = new Random();

        #region Add/Remove/Edit
        // •	Data can be added, edited and deleted.
        // •	The program must generate an error message if the text box is empty.
        private void ButtonAdd_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(TextBoxInput.Text))
            {
                if (nextEmpty < 24)
                {
                    Int32.TryParse(TextBoxInput.Text, out int temp);
                    astroArray[nextEmpty] = temp;
                    nextEmpty++;
                    //SortArray();
                    StripStatus.Text = "Data has been added";
                }
                else
                {
                    StripStatus.Text = "ERROR: Cannot add, list is already full";
                }
                DisplayArray();
                TextBoxInput.Clear();
            }
            else
            {
                StripStatus.Text = "ERROR: Enter a number in the Text Box";
            }

        }

        // Enables user to remove a selected item from the listbox
        private void ButtonRemove_Click(object sender, EventArgs e)
        {
            if (ListBoxOutput.SelectedIndex != -1)
            {
                int selected = ListBoxOutput.SelectedIndex;

                DialogResult delRecord = MessageBox.Show("Do you want to delete this record?",
                    "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (delRecord == DialogResult.Yes)
                {
                    astroArray[selected] = astroArray[nextEmpty - 1];
                    //SortArray();
                    StripStatus.Text = "Data has been deleted";
                    nextEmpty--;
                    DisplayArray();
                    TextBoxInput.Clear();
                }

                else
                {
                    StripStatus.Text = "Data was not deleted";
                }
            }
            else
            {
                StripStatus.Text = "ERROR: Cannot remove, no item selected";
            }
        }

        // Enables user to edit a selected item in the listbox
        // •	The program must generate an error message if the text box is empty.
        private void ButtonEdit_Click(object sender, EventArgs e)
        {
            // Checks to see if user has selected an item in the Listbox
            if (ListBoxOutput.SelectedIndex != -1)
            {
                // Checks to see if user has entered text to edit
                if (!string.IsNullOrEmpty(TextBoxInput.Text))
                {
                    int selected = ListBoxOutput.SelectedIndex;

                    // Code for Yes/No confirmation message
                    DialogResult delRecord = MessageBox.Show("Do you want to edit this record?",
                        "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    Int32.TryParse(TextBoxInput.Text, out int edited);
                    if (delRecord == DialogResult.Yes)
                    {
                        astroArray[selected] = edited;

                        DisplayArray();
                        TextBoxInput.Clear();
                        // Successful edit
                        StripStatus.Text = "Data has been edited";
                    }

                    else
                    {
                        // If user chooses not to edit
                        StripStatus.Text = "Data was not edited";
                    }
                }
                else
                {
                    // If user has selected Listbox item but hasn't entered number for editing
                    StripStatus.Text = "Enter your desired edit in the Text Box";
                }
            }
            else
            {
                // If user clicks button without selecting a Listbox item
                StripStatus.Text = "ERROR: Cannot edit, no item selected";
            }
        }
        #endregion

        #region Sort/Search
        // •	The client must be able to click a button to bubble sort the data.
        private void ButtonSort_Click(object sender, EventArgs e)
        {
            SortArray();
            DisplayArray();
        }

        // Bubble Sort algorithm
        private void SortArray()
        {
            // Checks that Listbox isn't empty before sorting
            if (nextEmpty > 0)
            {
                for (int i = 0; i < nextEmpty; i++)
                {
                    for (int j = i + 1; j < nextEmpty; j++)
                    {
                        if (astroArray[i] > astroArray[j])
                        {
                            int temp = astroArray[i];
                            astroArray[i] = astroArray[j];
                            astroArray[j] = temp;
                        }
                    }
                }
                StripStatus.Text = "Data sorted in ascending order";
            }
            else
            {
                StripStatus.Text = "ERROR: Cannot sort, no data in list";
            }
        }

        // •	The client can use a text box input to search the array.
        // •	The client must be able to enter search data and click a button to activate a binary search.
        // •	The program must generate an error message if the search is not successful.
        // •	The program must generate a message if the search is successful.
        private void ButtonSearch_Click(object sender, EventArgs e)
        {
            // Checks whether list is empty before searching
            if (nextEmpty > 0)
            {
                // Checks if user has entered a search query in the Text Box
                if (!string.IsNullOrEmpty(TextBoxInput.Text))
                {
                    SortArray();
                    DisplayArray();
                    Int32.TryParse(TextBoxInput.Text, out int target);
                    int lowBound = 0;
                    int highBound = max - 1;
                    int mid = 0;
                    bool found = false;

                    while (lowBound <= highBound)
                    {
                        mid = (lowBound + highBound) / 2;
                        if (target == astroArray[mid])
                        {
                            found = true;
                            break;
                        }
                        else if (target > astroArray[mid])
                        {
                            lowBound = mid + 1;
                        }
                        else
                        {
                            highBound = mid - 1;
                        }
                    }

                    if (found)
                    {
                        TextBoxInput.Clear();
                        ListBoxOutput.SelectedIndex = mid;
                        StripStatus.Text = "Search target " + target + " found at element " + (mid + 1);
                    }
                    else
                    {
                        TextBoxInput.Clear();
                        StripStatus.Text = "ERROR: Search target " + target + " not found";
                    }
                }
                else
                {
                    // If user hasn't entered a search query
                    StripStatus.Text = "ERROR: Enter a search query in the Text Box";
                }
            }
            else
            {
                // If list is empty
                StripStatus.Text = "ERROR: Cannot search, no data in list";
            }

        }
        #endregion

        #region Utilities

        // •	The program must load random data into the array using a button click.
        // •	The array is filled with random integers to simulate the data stream (numbers between 10 and 99).
        private void ButtonFill_Click(object sender, EventArgs e)
        {
            // If list is empty, fill with data
            if (nextEmpty == 0)
            {
                for (int x = 0; x < max; x++)
                {
                    astroArray[x] = rnd.Next(10, 99);
                    nextEmpty++;
                    DisplayArray();
                    StripStatus.Text = "Array filled with randomly-generated data";
                }
            }
            // If list contains data, ask for confirmation before overwriting
            else
            {
                DialogResult delRecord = MessageBox.Show("Do you want to generate new data? (Current data will be overwritten)",
                       "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (delRecord == DialogResult.Yes)
                {
                    nextEmpty = 0;
                    for (int x = 0; x < max; x++)
                    {
                        astroArray[x] = rnd.Next(10, 99);
                        nextEmpty++;
                        DisplayArray();
                        StripStatus.Text = "Array filled with randomly-generated data";
                    }
                }

                else
                {
                    StripStatus.Text = "Data was not overwritten";
                }
                
            }
        }

        // •	All data is displayed in a ListBox.
        private void DisplayArray()
        {
            ListBoxOutput.Items.Clear();
            for (int y = 0; y < nextEmpty; y++)
            {
                ListBoxOutput.Items.Add(astroArray[y]);
            }
        }
        
        // Prevents non-integer input from user
        private void TextBoxInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar))
                e.Handled = true;
        }
        #endregion
    }
}
